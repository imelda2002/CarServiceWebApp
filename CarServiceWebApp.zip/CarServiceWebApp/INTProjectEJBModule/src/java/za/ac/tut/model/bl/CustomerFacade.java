/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.tut.model.bl;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import za.ac.tut.model.entity.Customer;

/**
 *
 * @author imeld
 */
@Stateless
public class CustomerFacade extends AbstractFacade<Customer> implements CustomerFacadeLocal {

    @PersistenceContext(unitName = "INTProjectEJBModulePU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public CustomerFacade() {
        super(Customer.class);
    }
    public void printCustomerDetails(Long id) {
        // This find() call automatically joins both tables
        Customer customer = em.find(Customer.class, id);

        if (customer != null) {
            // Retrieve the secondary table fields using getters
            String type = customer.getServiceType();
            String status = customer.getStatus();
            String priority = customer.getPrefferedDate();

            System.out.println("Service: " + type + " | Status: " + status);
        }
    }
/////

    @Override
    public Customer findByRegistration(String registrationNumber) {
        try {
            // Select c from Customer where c.registrationNumber matches
            Query query = em.createQuery("SELECT c FROM Customer c WHERE c.registrationNumber = :regNum");
            query.setParameter("regNum", registrationNumber);
            
            // Returns the single customer found
            return (Customer) query.getSingleResult();
        } catch (Exception e) {
            // Returns null if no customer is found with that registration number
            return null;
        }
    }
    

} 
    
    
    

