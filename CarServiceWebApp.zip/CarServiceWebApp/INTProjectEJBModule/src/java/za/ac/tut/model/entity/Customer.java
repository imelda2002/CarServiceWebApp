/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.tut.model.entity;

import java.io.Serializable;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SecondaryTable;
import javax.persistence.Table;

/**
 *
 * @author imeld
 */
@Entity
@Table(name="Csutomer")
@SecondaryTable(name = "Service_Request", 
    pkJoinColumns = @PrimaryKeyJoinColumn(name = "customer_id"))
public class Customer implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String name;
    private String surname;
    private String contactNumber;
    private String model;
    private String brand;
    private String fielType;
    private String colour;
    private String registrationNumber;
    private Integer carYear;
    private String notes;
    @Column(table = "Service_Request", name = "service_type")
    private String serviceType;
    @Column(table = "Service_Request", name = "status")
    private String status;
    @Column(table = "Service_Request", name = "preffered_date")
    private String prefferedDate;

    public Customer() {
    }

    public Customer(Long id, String name, String surname, String contactNumber, String model, String brand, String fielType, String colour, String registrationNumber, Integer carYear, String notes, String serviceType, String status, String prefferedDate) {
        this.id = id;
        this.name = name;
        this.surname = surname;
        this.contactNumber = contactNumber;
        this.model = model;
        this.brand = brand;
        this.fielType = fielType;
        this.colour = colour;
        this.registrationNumber = registrationNumber;
        this.carYear = carYear;
        this.notes = notes;
        this.serviceType = serviceType;
        this.status = status;
        this.prefferedDate = prefferedDate;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

   

    public String getServiceType() {
        return serviceType;
    }

    public void setServiceType(String serviceType) {
        this.serviceType = serviceType;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getPrefferedDate() {
        return prefferedDate;
    }

    public void setPrefferedDate(String prefferedDate) {
        this.prefferedDate = prefferedDate;
    }

   


  

    public String getFielType() {
        return fielType;
    }

    public void setFielType(String fielType) {
        this.fielType = fielType;
    }

    

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getColour() {
        return colour;
    }

    public void setColour(String colour) {
        this.colour = colour;
    }

    public String getRegistrationNumber() {
        return registrationNumber;
    }

    public void setRegistrationNumber(String registrationNumber) {
        this.registrationNumber = registrationNumber;
    }

    public Integer getCarYear() {
        return carYear;
    }

    public void setCarYear(Integer carYear) {
        this.carYear = carYear;
    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Customer)) {
            return false;
        }
        Customer other = (Customer) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "za.ac.tut.model.entity.Customer[ id=" + id + " ]";
    }
    
}
