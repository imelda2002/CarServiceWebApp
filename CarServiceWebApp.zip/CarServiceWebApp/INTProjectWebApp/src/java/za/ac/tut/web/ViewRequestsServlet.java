/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.model.bl.CustomerFacadeLocal;
import za.ac.tut.model.entity.Customer;

/**
 *
 * @author imeld
 */
public class ViewRequestsServlet extends HttpServlet {

    @EJB
    private CustomerFacadeLocal customerFacade;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        
        String action = request.getParameter("action");
        if ("attend".equals(action)) {
            Long id = Long.parseLong(request.getParameter("id"));
            Customer c = customerFacade.find(id);
            if (c != null) {
                customerFacade.remove(c); // Remove from DB once attended
            }
        }

       
        List<Customer> customers = customerFacade.findAll();
        request.setAttribute("customers", customers);
        
        
        request.getRequestDispatcher("request_outcome.jsp").forward(request, response);
    }
    
    
}
            
    
