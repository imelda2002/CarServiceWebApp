/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package za.ac.tut.web;

import java.io.IOException;


import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.model.bl.CustomerFacadeLocal;
import za.ac.tut.model.entity.Customer;


/**
 *
 * @author imeld
 */
@WebServlet(name = "RequestServiceServlet", urlPatterns = {"/RequestServiceServlet"})
public class RequestServiceServlet extends HttpServlet {
@EJB
private CustomerFacadeLocal cfl;

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String registrationNumber=request.getParameter("registrationNumber");
         String contactNumber=request.getParameter("contactNumber");
         String serviceType=request.getParameter("serviceType");
         String Notes =request.getParameter("notes");
        String prefferedDate = request.getParameter("preferredDate");
         
         
         Customer customer=createRequest(registrationNumber,contactNumber,serviceType,prefferedDate,Notes);
         cfl.create(customer);
         request.setAttribute("customer", customer);
         
         RequestDispatcher disp =request.getRequestDispatcher("service_request_outcome.jsp");
         disp.forward(request, response);
}

    private Customer createRequest(String registrationNumber, String contactNumber,String serviceType, String prefferedDate, String Notes) {
        Customer cust=new Customer();
        cust.setServiceType(serviceType);
        cust.setRegistrationNumber(registrationNumber);
        cust.setNotes(Notes);
        cust.setPrefferedDate(prefferedDate);
        cust.setContactNumber(contactNumber);
        return cust;
    }
}        
     
  
      


 
            

    
    
   

