package za.ac.tut.web;

import java.io.IOException;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.model.bl.CustomerFacadeLocal;
import za.ac.tut.model.entity.Customer;

public class RegisterCustomer extends HttpServlet {

    @EJB
    private CustomerFacadeLocal cfl;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
      Long id=Long.parseLong(request.getParameter("id"));
      String name=request.getParameter("name");
      String surname=request.getParameter("surname");
      String registrationNumber=request.getParameter("registrationNumber");
      String colour=request.getParameter("colour");
      String model=request.getParameter("model");
      String brand=request.getParameter("brand");
      String contactNumber =request.getParameter("contactNumber");
      String fielType =request.getParameter("fuelType");
      int carYear =Integer.parseInt(request.getParameter("carYear"));
      
      
      Customer customer =createCustomer(id,name,surname,registrationNumber,colour,model,brand,contactNumber,fielType,carYear);
      cfl.create(customer);
      
       RequestDispatcher disp= request.getRequestDispatcher("register_outcome.jsp");
       disp.forward(request, response); 
      
}

    private Customer createCustomer(Long id, String name, String surname, String registrationNumber, String colour, String model, String brand, String contactNumber, String fielType, int carYear) {
      Customer cust =new Customer();
      cust.setBrand(brand);
      cust.setCarYear(carYear);
      cust.setColour(colour);
      cust.setFielType(fielType);
      cust.setId(id);
      cust.setName(name);
      cust.setSurname(surname);
      cust.setRegistrationNumber(registrationNumber);
      cust.setModel(model);
      cust.setContactNumber(contactNumber);
      
      
     return cust;
      
    }
}     
    
    
