<%@page import="za.ac.tut.model.entity.Customer"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Service Request Outcome</title>
        <!-- Adding Font Awesome for the back icon -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
        <style>
            body {
                font-family: 'Segoe UI', Arial, sans-serif;
                margin: 0;
                padding: 0;
                display: flex;
                justify-content: center;
                align-items: center;
                min-height: 100vh;
                /* Gray background overlay matching Screenshot 2026-05-13 161956_3.png */
                background: linear-gradient(rgba(128, 128, 128, 0.9), rgba(128, 128, 128, 0.9)),
                            url('https://c7.alamy.com/comp/RJMNY8/car-service-icon-on-white-background-for-graphic-and-web-design-modern-simple-vector-sign-internet-concept-trendy-symbol-for-website-design-web-button-or-mobile-app-RJMNY8.jpg');
                background-size: cover;
                background-position: center;
            }

            .outcome-card {
                background: white;
                padding: 60px 40px;
                border-radius: 12px;
                box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
                text-align: center;
                max-width: 700px;
                width: 90%;
                /* Distinct red top border from the screenshot */
                border-top: 6px solid #c0392b; 
            }

            h1 {
                color: #333;
                font-size: 26px;
                font-weight: 700;
                margin-bottom: 25px;
            }

            .info-text {
                color: #555;
                font-size: 17px;
                line-height: 1.8;
                margin: 0;
            }

            .info-text b {
                color: #000;
                font-weight: 800;
            }

            .status-text {
                color: #888;
                font-size: 15px;
                margin-top: 30px;
                letter-spacing: 0.5px;
            }

            .back-nav {
                position: absolute;
                top: 25px;
                right: 40px;
            }

            .back-link {
                text-decoration: none;
                color: white;
                font-weight: bold;
                font-size: 13px;
                opacity: 0.8;
                transition: opacity 0.3s;
            }

            .back-link:hover {
                opacity: 1;
            }
            .glass-card {
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            padding: 30px; border-radius: 15px; width: 95%; max-width: 1100px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.5); border-top: 6px solid #c0392b;
        }
        .navbar{
          position: absolute;
          top: 30px; 
          right: 5%;   
          z-index: 10;
          color: #ffffff;
         
         decoration: none;
        font-family: 'Arial Black', sans-serif;
        font-size: 14px;
        letter-spacing: 1px;
        transition: opacity 0.3s ease;
        }
        .navbar{
          position: absolute;
          top: 30px; 
          right: 5%;   
          z-index: 10;
          color: #ffffff;
         
         decoration: none;
        font-family: 'Arial Black', sans-serif;
        font-size: 14px;
        letter-spacing: 1px;
        transition: opacity 0.3s ease;
        }
        </style>
    </head>
    <body>
           <nav class="navbar">
                <a href="Logout.do" class="back-link"><i class="fa-solid fa-arrow-left"></i> BACK TO HOME</a>
        </nav>
        <div class="glass-card">
        <div class="back-nav">
            <a href="Logout.do" class="back-link">
                <i class="fa-solid fa-arrow-left"></i> BACK TO HOME
            </a>
        </div>

       <%
       Customer customer=(Customer)request.getAttribute("customer");
       
         String registrationNumber =customer.getRegistrationNumber();
        String serviceType =customer.getServiceType();
        String preferredDateStr = customer.getPrefferedDate();
        String notes =customer.getNotes();
       %>
        
        
       <p class="info-text">
                    Customer with <b><%=registrationNumber%></b> has successfully <br>
                    requested a <b><%=serviceType%></b>, preferred on <b><%=preferredDateStr%></b>
       </p>
                
        </div>        
    </body>
</html>