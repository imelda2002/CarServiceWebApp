<%-- 
    Document   : newjsp
    Created on : May 12, 2026, 1:46:30 PM
    Author     : imeld
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Register Outcome</title>
        <style>
            body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                margin: 0;
                padding: 0;
                display: flex;
                justify-content: center;
                align-items: center;
                min-height: 100vh;
                /* Replace 'background.png' with your actual file path */
                background: linear-gradient(rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.4)),
                    url('https://c7.alamy.com/comp/RJMNY8/car-service-icon-on-white-background-for-graphic-and-web-design-modern-simple-vector-sign-internet-concept-trendy-symbol-for-website-design-web-button-or-mobile-app-RJMNY8.jpg'); /* Replace with your actual filename */
                background-size: 50%; /* Adjust size to match the icon style */
                background-color: #f4f7f6;
            }
            .navbar{
                position: absolute;
                top: 30px;
                right: 5%;
                z-index: 10;


                color: white;
                text-decoration: none;
                font-family: 'Arial Black', sans-serif;
                font-size: 14px;
                letter-spacing: 1px;
                transition: opacity 0.3s ease;
            }
              .glass-card {
                /* This creates the semi-transparent white effect */
                background: rgba(255, 255, 255, 0.4);
                /* This creates the blur effect on the car image behind the card */
                backdrop-filter: blur(8px);
                -webkit-backdrop-filter: blur(8px);
                
                padding: 40px;
                border-radius: 20px;
                box-shadow: 0 10x 30px rgba(0, 0, 0, 0.1);
                text-align: center;
                max-width: 450px;
                width: 85%;
                border: 1px solid rgba(255, 255, 255, 0.2);
            }
             h1 {
                color: #2d2d2d;
                font-size: 2rem;
                margin-top: 0;
                margin-bottom: 15px;
            }

            p {
                color: #555;
                font-size: 0.95rem;
                line-height: 1.6;
                margin-bottom: 30px;
                padding: 0 10px;
            }

        </style>
    </head>
    <body>
        <nav class="navbar">
            <a href="Logout.do" class="back-link"><i class="fa-solid fa-arrow-left"></i> BACK TO HOME</a>
        </nav>
         <div class="glass-card">
        <h1>Register Outcome</h1>
        <p>
            Customer successfully registered
        </p>
         </div>
    </body>
</html>
