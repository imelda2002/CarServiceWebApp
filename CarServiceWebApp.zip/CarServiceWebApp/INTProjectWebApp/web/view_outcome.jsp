<%-- 
    Document   : view_outcome
    Created on : May 12, 2026, 1:29:53 PM
    Author     : imeld
--%>

<%@page import="java.util.List"%>
<%@page import="za.ac.tut.model.entity.Customer"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Get All Customers</title>
        <style>
             body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                margin: 0;
                padding: 0;
                display: flex;
                justify-content: center;
                align-items: center;
                min-height: 100vh;
                /* Replace 'background.png' with your actual file path */
                background: linear-gradient(rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.4)),
                    url('https://c7.alamy.com/comp/RJMNY8/car-service-icon-on-white-background-for-graphic-and-web-design-modern-simple-vector-sign-internet-concept-trendy-symbol-for-website-design-web-button-or-mobile-app-RJMNY8.jpg'); /* Replace with your actual filename */
                background-size: 50%; /* Adjust size to match the icon style */
                background-color: #f4f7f6;
            }
            .container {
                background: white;
                padding: 2rem;
                border-radius: 12px;
                box-shadow: 0 10px 25px rgba(0,0,0,0.1);
                width: 90%;
                max-width: 1000px;
                text-align: center;
                border-top: 5px solid #c0392b; /* Matches the red in Screenshot 2026-05-12 164817.png */
            }
            h1 {
                color: #333;
                margin-bottom: 0.5rem;
            }
            p {
                color: #666;
                margin-bottom: 2rem;
            }
            table {
                width: 100%;
                border-collapse: collapse;
                margin-top: 20px;
            }
            th, td {
                  padding: 12px 15px;
                  text-align: left; /* Strict alignment for both head and data */
                  border-bottom: 1px solid #ddd;
                 word-wrap: break-word;
         }
            th {
              background-color: #c0392b;
              color: white;
              text-transform: uppercase;
              font-size: 0.85rem;
               letter-spacing: 0.5px;
             }
            td {
                padding: 12px;
                border-bottom: 1px solid #ddd;
                color: #444;
                text-align: left;
            }
            tr:hover {
                background-color: #f9f9f9;
            }
         .navbar{
          position: absolute;
          top: 30px; 
          right: 5%;   
          z-index: 10;
          color: #ffffff;
         
         decoration: none;
        font-family: 'Arial Black', sans-serif;
        font-size: 14px;
        letter-spacing: 1px;
        transition: opacity 0.3s ease;
        }
        </style>
    </head>
    <body>
        <nav class="navbar">
                <a href="Logout.do" class="back-link"><i class="fa-solid fa-arrow-left"></i> BACK TO HOME</a>
        </nav>
        <div class="container">
        <h1>Get All Customers</h1>
        <%
        List<Customer> customers =(List<Customer>)request.getAttribute("customers");
        %>
        
        <p>Below are all the customers</p>
        <table>
            <th>ID</th>
            <th>Name</th>
            <th>Surname</th>
            <th>Contact Number</th>
            <th>Model</th>
            <th>Brand</th>
            <th>Colour</th>
            <th>Registration Number</th>
            <th>Fuel Type</th>
            <th>Car Year</th>
            
            <%
            for(int i=0;i<customers.size();i++){
                Customer customer = customers.get(i);
                Long id =customer.getId();
                String name=customer.getName();
                String surname=customer.getSurname();
                String contactNumber=customer.getContactNumber();
                String model=customer.getModel();
                String brand=customer.getBrand();
                String colour=customer.getColour();
                String registrationNumber=customer.getRegistrationNumber();
                String fuelType =customer.getFielType();
                Integer carYear=customer.getCarYear();
                %>
                <tr>
                    <td><%=id%></td>
                    <td><%=name%></td>
                    <td><%=surname%></td>
                    <td><%=contactNumber%></td>
                    <td><%=model%></td>
                    <td><%=brand%></td>
                    <td><%=colour%></td>
                    <td><%=registrationNumber%></td>
                    <td><%=fuelType%></td>
                    <td><%=carYear%></td>
                </tr>
                 
               <%  
                }
            
                %>
            
            
        </table>
        </div>
    </body>
</html>
