<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Login Page</title>
        <style>
            body {
                background-color: #808080; /* Gray background from Screenshot 2026-05-13 161956.png */
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
                margin: 0;
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            }

            .login-card {
                background-color: white;
                padding: 40px 60px;
                border-radius: 15px;
                box-shadow: 0 10px 25px rgba(0,0,0,0.2);
                text-align: center;
                width: 400px;
                border-top: 5px solid #a52a2a; /* Red top border matching the car theme */
            }

            h1 {
                color: #333;
                margin-bottom: 30px;
                font-weight: 700;
            }

            table {
                width: 100%;
            }

            td {
                padding: 10px 0;
                text-align: left;
                color: #555;
            }

            input[type="text"], input[type="password"] {
                width: 100%;
                padding: 10px;
                border: 1px solid #ccc;
                border-radius: 5px;
                box-sizing: border-box; /* Ensures padding doesn't affect width */
            }

            input[type="submit"] {
                background-color: #333;
                color: white;
                border: none;
                padding: 12px 30px;
                border-radius: 5px;
                cursor: pointer;
                font-weight: bold;
                transition: background 0.3s;
                margin-top: 20px;
                width: 100%;
            }

            input[type="submit"]:hover {
                background-color: #a52a2a; /* Changes to theme red on hover */
            }
        </style>
    </head>
    <body>
        <div class="login-card">
            <h1>Login</h1>
            <form action="j_security_check" method="POST">
                <table>
                    <tr>
                        <td>Username:</td>
                    </tr>
                    <tr>
                        <td><input type="text" name="j_username" required="" placeholder="Enter username" /></td>
                    </tr>
                    <tr>
                        <td>Password:</td>
                    </tr>
                    <tr>
                        <!-- Changed type to password for security -->
                        <td><input type="password" name="j_password" required="" placeholder="Enter password" /></td>
                    </tr>
                    <tr>
                        <td><input type="submit" value="Login" /></td>
                    </tr>
                </table>
            </form>
        </div>
    </body>
</html>