<%-- 
    Document   : unathorised_access
    Created on : Jun 15, 2026, 5:47:39 PM
    Author     : imeld
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Error Page</title>
        <style>
              body {
                background-color: #808080; /* Gray background from Screenshot 2026-05-13 161956.png */
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
                margin: 0;
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            }

            .error {
                background-color: white;
                padding: 40px 60px;
                border-radius: 15px;
                box-shadow: 0 10px 25px rgba(0,0,0,0.2);
                text-align: center;
                width: 400px;
                border-top: 5px solid #a52a2a; /* Red top border matching the car theme */
            }

            h1 {
                color: #333;
                margin-bottom: 30px;
                font-weight: 700;
            }
               .navbar{
    position: absolute;
    top: 30px; 
    right: 5%;   
    z-index: 10; 
    
  
    color: white;
    text-decoration: none;
    font-family: 'Arial Black', sans-serif;
    font-size: 14px;
    letter-spacing: 1px;
    transition: opacity 0.3s ease;
}
        </style>
    </head>
    <body>
        <nav class="navbar">
                <a href="Logout.do" class="back-link"><i class="fa-solid fa-arrow-left"></i> BACK TO HOME</a>
        </nav>
        <div class="error">
           <h1>You Do Not Access to this page</h1>  
        </div>
       
        
     
</html>
