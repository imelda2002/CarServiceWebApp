<%-- 
    Document   : login_err
    Created on : May 13, 2026, 10:57:03 PM
    Author     : imeld
--%>

<%@page  contentType="text/html" pageEncoding="UTF-8" isErrorPage=""%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Login Error  Page</title>
    </head>
    <body>
        <h1>Login Error</h1>
        
        <ul>
            <li><a href="index.html">Home Page</a></li>
        </ul>
    </body>
</html>
