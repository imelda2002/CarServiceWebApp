<%-- 
    Document   : request_outcome
    Created on : May 13, 2026, 4:38:41 PM
    Author     : imeld
--%>

<%@page import="java.util.List"%>
<%@page import="za.ac.tut.model.entity.Customer"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Request Outcome</title>
        <style>
        body {
            margin: 0; padding: 20px; display: flex; justify-content: center;
            background: linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url('https://c7.alamy.com/comp/RJMNY8/car-service-icon-on-white-background-for-graphic-and-web-design-modern-simple-vector-sign-internet-concept-trendy-symbol-for-website-design-web-button-or-mobile-app-RJMNY8.jpg');
            background-size: cover; font-family: 'Segoe UI', sans-serif;
        }
        .glass-card {
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            padding: 30px; border-radius: 15px; width: 95%; max-width: 1100px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.5); border-top: 6px solid #c0392b;
        }
        h1 { color: #333; text-align: center; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; background: white; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #eee; font-size: 14px; }
        th { background: #2c3e50; color: white; text-transform: uppercase; }
        tr:hover { background: #f9f9f9; }
        .btn-attend {
            background: #27ae60; color: white; padding: 8px 15px;
            text-decoration: none; border-radius: 5px; font-weight: bold;
        }
        .btn-attend:hover { background: #219150; }
         .navbar{
    position: absolute;
    top: 30px; 
    right: 5%;   
    z-index: 10; 
    
  
    color: white;
    text-decoration: none;
    font-family: 'Arial Black', sans-serif;
    font-size: 14px;
    letter-spacing: 1px;
    transition: opacity 0.3s ease;
}
    </style>
    </head>
   <body>
        <nav class="navbar">
            <a href="Logout.do" class="back-link"><i class="fa-solid fa-arrow-left"></i> BACK TO HOME</a>
        </nav>

<div class="glass-card">
    <h1><i class="fa-solid fa-list-check"></i> Pending Service Requests</h1>
    <%
        List<Customer> customers =(List<Customer>)request.getAttribute("customers");
        %>
        
        <p>Below are all the customers</p>
        <table>
            
           
           <th>Registration Number</th>
            <th>Contact Number</th>
            <th>Service Type</th>
              <th>Preffered Date</th>
            <th>Note</th>
          
            
            <%
            for(int i=0;i<customers.size();i++){
                Customer customer = customers.get(i);
                String contactNumber=customer.getContactNumber();
                String registrationNumber=customer.getRegistrationNumber();
                String serviceType =customer.getServiceType();
                String notes=customer.getNotes();
                String prefferdDate =customer.getPrefferedDate();
                %>
                <tr>
                     <td><%=registrationNumber%></td>
                      <td><%=contactNumber%></td>
                    <td><%= serviceType%></td>
                    <td><%=prefferdDate%></td>
                    <td><%=notes%></td>
                   
                </tr>
                 
               <%  
                }
            
                %>
            
            
        </table>
</div>

</body>
</html>
